<script setup>
import { RouterLink, RouterView } from "vue-router";

import Navigation from "./components/Navigation.vue";
import ImgPlaceholder from "./components/ImgPlaceholder.vue";
import InnerNavigation from "./components/InnerNavigation.vue";
import HighlightSpec from "./components/HighlightSpec.vue";
import FooterVue from "./components/Footer.vue";
import ImgCarousel from "./components/ImgCarousel.vue";
import DataCarousel from "./components/DataCarousel.vue";
</script>

<template>
  <Navigation />

  <main>
    <ImgPlaceholder class="y-mandatory-scroll-snapping" />

    <InnerNavigation class="y-mandatory-scroll-snapping" />
    <HighlightSpec />
    <ImgCarousel />
    <DataCarousel />
  </main>

  <footer>
    <FooterVue />
  </footer>
</template>

<style scoped>
/* main {
  Nvaigation bar indent
   margin-top: 0;
  
  scroll-snap-align: center;
  flex: none;
  height: 5000px;
} */

.x-mandatory-scroll-snapping {
  scroll-snap-type: x mandatory;
}
.x-proximity-scroll-snapping {
  scroll-snap-type: x proximity;
}
.y-mandatory-scroll-snapping {
  scroll-snap-type: y mandatory;
}
.y-proximity-scroll-snapping {
  scroll-snap-type: y proximity;
}
</style>
