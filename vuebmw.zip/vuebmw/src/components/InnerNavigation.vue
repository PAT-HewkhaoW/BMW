<template>
  <div class="container">
    <div class="container Nav-container">
      <div class="item selected">Highlight</div>
      <div class="item">Technical Data</div>
      <div class="item">Technical Data</div>
      <div class="item">Service & Assistance</div>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style lang="css" scoped>
.Nav-container {
  min-width: 100vw;

  gap: 25px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
}

.item {
  padding: 16px 18px;
  font-family: Poppins;
  font-weight: 600;
  height: 100%;
}

.item.selected {
  border-bottom: 7px solid var(--vt-c-primary);
}

.blank {
  height: 100vh;
}
</style>
