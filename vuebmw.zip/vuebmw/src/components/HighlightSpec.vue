<template>
  <div class="container">
    <div class="img-hl">
      <img
        src="https://images.prismic.io/carwow/8c4b0999-6a4e-4501-a94c-06758e3f445f_P90415136_highRes_the-new-bmw-m4-compe.jpg?fit=clip&q=60&w=750&cs=tinysrgb&auto=format"
        alt=""
        class="thehl"
      />
    </div>
    <div class="content-hl">
      <div class="title-container">
        <div class="title">BMW M4 Competition M xDrive Coupé.</div>
        <div class="subtitle">
          Maximum driving dynamics with rear-wheel drive.
        </div>
      </div>
      <div class="spec-container">
        <div class="item">
          <div class="items title">510</div>
          <div class="items subtitle">horsepower</div>
          <div class="items title">650 Nm</div>
          <div class="items subtitle">Torque</div>
          <div class="items title">3.2 s</div>
          <div class="items subtitle">0-100 km/h</div>
          <div class="items title">8-speed</div>
          <div class="items subtitle">SPORT AUTOMATIC TRANSMISSION</div>
          <div class="items title">RWD</div>
          <div class="items subtitle">rear-wheel drive</div>
        </div>
      </div>
      <div class="CTA-container">
        <div class="L-nav">M4 Competition M xDrive Coupé</div>
        <div class="R-nav">M4 Competition Coupé</div>
      </div>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style scoped>
.container {
  min-width: 100vw;
  display: flex;
  gap: 0;
  align-items: center;
}

/* .img-hl {
} */

.img-hl img {
  min-width: 64vw;
  height: 720px;
}
.content-hl {
  min-width: 36vw;
  height: 720px;
  padding: 40px 40px;

  background-color: #161616;
  display: flex;
  flex-direction: column;
}

.title,
.subtitle {
  font-family: Poppins;
  color: white;
}

.L-nav,
.R-nav {
  color: #e0ff36;
}
.title {
  font-size: 30px;
  font-weight: 600;
}

.item .title {
  margin-top: 5px;
}
.item .subtitle {
  margin-bottom: 5px;
}
.subtitle {
  font-size: 17px;
  font-weight: 400;
}

.thehl {
  width: 100%;
  object-fit: cover;
}
.item {
  display: flex;
  flex-direction: column;

  justify-items: center;
}

.items {
  text-align: center;
}

.spec-container {
  display: block;
  margin-top: auto;
  margin-bottom: auto;
  justify-content: center;
}

.CTA-container {
  display: flex;
  width: 100%;
  justify-content: space-between;
}

.title-container .spec-container .CTA-container {
  margin-top: 2em;
}
</style>
