<script>
import IconCTAarrowRight from "./icons/IconCTAarrowRight.vue";
export default {
  components: {
    IconCTAarrowRight,
  },

  data() {
    return {
      // Initialize hover state
    };
  },
  methods: {},
};
</script>
<template>
  <div class="container main-container">
    <div class="container spec-container">
      <ul class="container">
        <li class="spec">
          <div class="title">510 hp / 375 kW</div>
          <div class="subtitle">horse power (hp) / kilowatt kW</div>
        </li>
        <li class="spec">
          <div class="title">3.9 s</div>
          <div class="subtitle">Accelation 0 - 100 km/h</div>
        </li>
        <li class="spec">
          <div class="title">650 Nm</div>
          <div class="subtitle">Torque</div>
        </li>
      </ul>
      <div class="hyperlinkbtn">
        <IconCTAarrowRight msg="Build Your Own" />

        <IconCTAarrowRight msg="Technical Data" />

        <IconCTAarrowRight msg="Test Drive" />

        <IconCTAarrowRight msg="Request for offer" />
      </div>
      <div class="varient">
        <button class="varientbtn">BMW M4 Competition Coupé</button>
        <button class="varientbtn Selected">
          BMW M4 Competition M xDrive Coupé.
        </button>
        <button class="varientbtn">BMW M4 Coupé</button>
      </div>
    </div>
  </div>
</template>
<style lang="css" scoped>
.main-container {
  display: flex;
  width: 1920px;
  padding: 0 10%;
  justify-content: center;
  align-items: flex-start;
  gap: 5px;
}

.spec-container {
  display: flex;
  width: 100%;
  padding: 28px 0px;
  flex-direction: column;
  align-items: center;
  gap: 40px;
  flex-shrink: 0;
}

ul {
  display: inline-flex;
  justify-content: space-between;
}

.spec {
  display: flex;
  width: 290px;
  flex-direction: column;
  align-items: center;
  color: white;
}

.spec .title {
  font-family: Poppins;
  font-size: 31px;
  font-style: normal;
  font-weight: 500;
  line-height: normal;
}

.spec .subtitle {
  font-family: Poppins;
  font-size: 19px;
  font-style: normal;
  font-weight: 300;
  line-height: normal;
}

.hyperlinkbtn {
  display: flex;
  align-items: flex-start;
  gap: 21px;
}

.varient {
  display: flex;
  align-items: flex-start;
  gap: 52px;
}
.varientbtn {
  color: #a4a5a8;
  font-family: Poppins;
  font-size: 21px;
  font-style: normal;
  font-weight: 500;
  line-height: 50px; /* 238.095% */
}

.varientbtn.Selected {
  color: #fff;
  font-family: Poppins;
  font-size: 27px;
  font-style: normal;
  font-weight: 600;
  line-height: 50px;
}
</style>
