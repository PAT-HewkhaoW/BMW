<script>
export default {
  components: {},
  data() {
    return {
      dataElement: [
        {
          title: "BMW M TwinPower Turbo inline 6-cylinder petrol engine.",
          body: "The BMW M TwinPower Turbo inline 6-cylinder petrol engine features superior power delivery and the striking characteristic M engine sound. Two mono-scroll turbochargers, direct High-Precision Injection, fully variable valve control and variable camshaft control ensure outstanding performance.",
          focus: false,
          img: "https://www.bmw-m.com/content/dam/bmw/marketBMW_M/common/topics/magazine-article-pool/2021/entwickler-faq-08/AI_1_F8_highRes_the-new-bmw-m4-compe.jpg.asset.1624454414791.jpg",
        },
        {
          title: "8-speed M Steptronic with Drivelogic.",
          body: "The BMW M TwinPower Turbo inline 6-cylinder petrol engine features superior power delivery and the striking characteristic M engine sound. Two mono-scroll turbochargers, direct High-Precision Injection, fully variable valve control and variable camshaft control ensure",
          focus: false,
          img: "https://cdn.bmwblog.com/wp-content/uploads/2020/09/2021-bmw-m4-competition-interior-07.jpg",
        },
        {
          title: "M Carbon ceramic brake.",
          body: "The M Carbon ceramic brake delivers braking power more directly. It contributes to a lower vehicle weight, which has a positive impact on agility, dynamics and acceleration. The technical equipment is visible through carbon-ceramic brake discs and calipers in the colour Gold matt with M lettering on the front and rear",
          focus: false,
          img: "https://cdn.bmwblog.com/wp-content/uploads/2016/07/BMW-carbon-ceramic-brake.jpg",
        },
        {
          title: "M Sport exhaust system.",
          body: "The M Sport exhaust system delivers a dynamic sound that can be modified via the integrated exhaust valve mechanism. The SPORT and SPORT+ programmes, which can be selected via the SETUP button, are accentuated by an even more intense engine sound, while the comfort-oriented programme prioritises more discreet engine acoustics.",
          focus: false,
          img: "https://www.supersprint.com/public/img/1-488424-488430.jpg",
        },
      ],
      currentIndex: 0,
      selectedbg:
        "https://www.bmw-m.com/content/dam/bmw/marketBMW_M/common/topics/magazine-article-pool/2021/entwickler-faq-08/AI_1_F8_highRes_the-new-bmw-m4-compe.jpg.asset.1624454414791.jpg",
    };
  },
  methods: {
    focusElement(index) {
      this.resetElement();
      this.dataElement[index].focus = true;

      this.currentIndex = index;
    },
    resetElement() {
      for (let i = 0; i < this.dataElement.length; i++) {
        this.dataElement[i].focus = false;
      }
    },
    focusImage(index) {
      this.selectedbg = this.dataElement[this.currentIndex].img;
      this.currentIndex = index;
    },
  },
};
</script>
<template>
  <div class="main">
    <div class="img-carousels">
      <div class="overlay">
        <p class="title h2 font-avenir-heavy">
          BMW M4 Competition M xDrive Coupé hightlight.
        </p>
        <p class="txt-subtitle-1 h4 font-avenir-heavy">
          Driving dynamics and design features of the BMW M4 Competition M
          xDrive Coupé.
        </p>
      </div>
      <div
        class="img-display"
        :style="{ backgroundImage: 'url(' + selectedbg + ')' }"
      ></div>
    </div>
    <div class="data-carousels">
      <div class="item">
        <div
          class="data-item"
          v-for="(child, index) in dataElement"
          :key="index"
          :class="{ focus: child.focus }"
          @click="focusElement(index), focusImage(index)"
        >
          <p class="title">{{ child.title }}</p>
          {{ child.body }}
        </div>
      </div>
    </div>
    <div class="carousel-indicators">
      <div class="ctn">
        <span class="ind1" :class="{ 'ind ': this.currentIndex == 0 }"></span>
        <span class="ind2" :class="{ 'ind ': this.currentIndex == 1 }"></span>
        <span class="ind3" :class="{ 'ind ': this.currentIndex == 2 }"></span>
        <span class="ind4" :class="{ 'ind ': this.currentIndex == 3 }"></span>
      </div>
    </div>
  </div>
</template>
<style scoped lang="scss">
* {
  font-family: Poppins;
}
.main {
  width: 100vw;

  scroll-snap-type: mandatory y;
  background-color: #161616;
  .img-carousels {
    width: 100%;
    height: calc(66vh + 2rem);

    .overlay {
      width: 100vw;
      height: 15rem;
      position: absolute;
      z-index: 0;

      padding: 4rem 2rem;

      font-weight: 700;
      background: linear-gradient(
        180deg,
        #161616 31.39%,
        rgba(33, 33, 33, 0) 100%
      );

      color: white;
    }

    .img-display {
      width: 100%;
      height: 100%;
      background-repeat: no-repeat;
      background-size: cover;
      transition: 0.4s ease all;
    }
  }

  .data-carousels {
    width: 100%;
    height: 34vh;
    padding: 2rem;
    padding: 0 10vw;
    background-color: white;
    .item {
      height: 100%;
      display: flex;
      // flex-direction: column;
      justify-content: space-around;

      // width: 30%;

      .data-item {
        width: 25%;
        background-color: white;
        font-weight: 500;

        color: black;
        padding: 1.5rem 1.8rem;

        &.focus {
          transform: translateY(-40px);
          position: relative;
          box-shadow: 0px 0px 17px 0px rgba(0, 0, 0, 0.25);
          transition: 0.4s ease all;
        }

        font-size: 16px;
        p.title {
          font-weight: 700;
          font-size: 1.2rem;
          margin-bottom: 10px;
        }
      }
    }
  }

  .carousel-indicators {
    width: 100vw;
    height: 2rem;
    background-color: white;

    display: flex;
    justify-content: space-around;
    .ctn {
      position: relative;

      height: 100%;
      gap: 1rem;
      display: flex;
      align-items: center;
      span {
        border-radius: 50%;
        width: 0.6rem;
        height: 0.6rem;
        background-color: #5b5d67;
      }
      .ind {
        background-color: #37373d;
        transform: scale(1.2);
        transition: 1s ease all;
      }
    }
  }
}
</style>
