<template>
  <div class="main">
    <div class="title">
      <p class="title-main">BMW M4 COMPETITION COUPÉ – IMPRESSIONS.</p>
      <p class="sub-title">BMW M4 COMPETITION COUPÉ – IMPRESSIONS.</p>
    </div>
    <div class="img-carousel">
      <div class="slider">
        <div class="slider-L" @click="IndexDecrement">
          <svg
            width="12"
            height="21"
            viewBox="0 0 10 16"
            fill="#161616"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M7.51753 8L0.511964 1.02242C0.454286 0.966194 0.408687 0.899435 0.377806 0.826012C0.346924 0.752589 0.331373 0.673959 0.332053 0.594673C0.332732 0.515386 0.349628 0.437018 0.381765 0.364102C0.413901 0.291186 0.460638 0.225172 0.519272 0.169877C0.577906 0.114583 0.647272 0.0711079 0.723357 0.0419673C0.799442 0.0128267 0.880734 -0.00140064 0.962529 0.000108658C1.04432 0.00161796 1.125 0.0188339 1.19988 0.0507603C1.27477 0.0826866 1.34238 0.128689 1.3988 0.186106L8.82344 7.58184C8.93582 7.69379 8.9987 7.84381 8.9987 8C8.9987 8.15619 8.93582 8.30621 8.82344 8.41816L1.3988 15.8139C1.34238 15.8713 1.27477 15.9173 1.19988 15.9492C1.125 15.9812 1.04432 15.9984 0.962529 15.9999C0.880734 16.0014 0.799442 15.9872 0.723357 15.958C0.647272 15.9289 0.577906 15.8854 0.519272 15.8301C0.460638 15.7748 0.413901 15.7088 0.381765 15.6359C0.349628 15.563 0.332732 15.4846 0.332053 15.4053C0.331373 15.326 0.346924 15.2474 0.377806 15.174C0.408687 15.1006 0.454286 15.0338 0.511964 14.9776L7.51753 8Z"
            />
          </svg>
        </div>
        <div class="slider-R" @click="IndexIncrement">
          <svg
            width="12"
            height="21"
            viewBox="0 0 10 16"
            fill="#161616"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M7.51753 8L0.511964 1.02242C0.454286 0.966194 0.408687 0.899435 0.377806 0.826012C0.346924 0.752589 0.331373 0.673959 0.332053 0.594673C0.332732 0.515386 0.349628 0.437018 0.381765 0.364102C0.413901 0.291186 0.460638 0.225172 0.519272 0.169877C0.577906 0.114583 0.647272 0.0711079 0.723357 0.0419673C0.799442 0.0128267 0.880734 -0.00140064 0.962529 0.000108658C1.04432 0.00161796 1.125 0.0188339 1.19988 0.0507603C1.27477 0.0826866 1.34238 0.128689 1.3988 0.186106L8.82344 7.58184C8.93582 7.69379 8.9987 7.84381 8.9987 8C8.9987 8.15619 8.93582 8.30621 8.82344 8.41816L1.3988 15.8139C1.34238 15.8713 1.27477 15.9173 1.19988 15.9492C1.125 15.9812 1.04432 15.9984 0.962529 15.9999C0.880734 16.0014 0.799442 15.9872 0.723357 15.958C0.647272 15.9289 0.577906 15.8854 0.519272 15.8301C0.460638 15.7748 0.413901 15.7088 0.381765 15.6359C0.349628 15.563 0.332732 15.4846 0.332053 15.4053C0.331373 15.326 0.346924 15.2474 0.377806 15.174C0.408687 15.1006 0.454286 15.0338 0.511964 14.9776L7.51753 8Z"
            />
          </svg>
        </div>
      </div>
      <div
        class="img-display"
        :style="{ backgroundImage: 'url(' + dataImg[this.carouselIndex] + ')' }"
      ></div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      carouselIndex: 0,
      dataImg: [
        "https://www.bmw.co.th/content/dam/bmw/marketTH/common/All%20Models/bmw-m/m4-coupe/2019/the-all-new-bmw-m4-competition-coupe_4_xxl.jpg",
        "https://cdn.bmwblog.com/wp-content/uploads/2022/06/bmw-m4-speed-yellow-03.jpg",
        "https://www.bmw.co.th/content/dam/bmw/marketTH/common/All%20Models/bmw-m/m4-coupe/2019/mar-newsletter/the-all-new-bmw-m4-competition-coupe_30_xl.jpg",
        "https://carnetwork.s3.ap-southeast-1.amazonaws.com/file/f8b89b8702cd45b180ae337dc8fb5326.jpg",
      ],
    };
  },
  methods: {
    IndexDecrement() {
      if (this.carouselIndex < 1) {
        this.carouselIndex = this.dataImg.length - 1;
      } else if (this.carouselIndex < this.dataImg.length - 1) {
        this.carouselIndex -= 1;
        console.log(this.carouselIndex);
      }
    },

    IndexIncrement() {
      if (this.carouselIndex < this.dataImg.length - 1) {
        this.carouselIndex += 1;
      } else {
        this.carouselIndex = 0;
      }
    },
  },
};
</script>
<style lang="scss" scoped>
.main {
  width: 100vw;
  height: 100vh;
  background-color: white;
  padding-top: 10rem;

  .title {
    height: 9rem;
    padding: 1.5rem 3rem;
    font-family: Poppins;
    color: #161616;
    line-height: 1;
    p.title-main {
      font-size: 4rem;
      font-weight: 600;
    }

    p.sub-title {
      font-size: 2rem;
      font-weight: 400;
    }
  }

  .img-carousel {
    height: 86vh;
    position: relative;

    .slider {
      width: 100vw;
      justify-content: space-between;
      padding: 0 4vw;
      display: flex;
      top: 50%;
      position: absolute;
      svg {
        fill: #161616;
        transform: scale(4);
      }

      .slider-L {
        cursor: pointer;
        display: flex;
        justify-content: center;
        background-color: #16161660;
        align-items: center;
        border-radius: 50%;
        width: 60px;
        height: 60px;
        &:hover {
          background-color: rgba(255, 255, 255, 0.404) !important;
        }
        svg {
          &:hover {
            fill: white !important;
          }
          transform: scaleX(-1.7) scaleY(1.7);
        }
      }

      .slider-R {
        cursor: pointer;
        display: flex;
        justify-content: center;
        background-color: #16161660;
        align-items: center;
        border-radius: 50%;
        width: 60px;
        height: 60px;
        &:hover {
          background-color: rgba(255, 255, 255, 0.404) !important;
        }
        svg {
          &:hover {
            fill: white !important;
          }
          transform: scaleX(1.7) scaleY(1.7);
        }
      }
    }

    .img-display {
      // background-color: rgba(195, 203, 203, 0.322);
      width: 100%;
      height: 100%;
      background-size: cover;
      background-position: 60%;
      transition: 0.01s ease-in;
    }
  }
}
</style>
