<template>
  <!-- <svg
    :class="{ hovered: isHovered }"
    @mouseover="() => (this.isHovered = true)"
    @mouseout="() => (this.isHovered = false)"
    xmlns="http://www.w3.org/2000/svg"
    width="12"
    height="21"
    viewBox="0 0 12 21"
    fill="#fff"
  >
    <path
      d="M1.2629 2.18139C1.17268 2.08592 1.10215 1.97361 1.05534 1.85088C1.00852 1.72816 0.986338 1.59741 0.990052 1.46611C0.993766 1.3348 1.02331 1.20552 1.07698 1.08563C1.13066 0.965747 1.20743 0.857608 1.3029 0.76739C1.39837 0.677172 1.51068 0.606641 1.63341 0.559826C1.75614 0.51301 1.88688 0.490826 2.01819 0.494541C2.14949 0.498255 2.27877 0.527795 2.39866 0.581474C2.51854 0.635152 2.62668 0.711919 2.7169 0.80739L11.2169 9.80739C11.3924 9.99306 11.4902 10.2389 11.4902 10.4944C11.4902 10.7499 11.3924 10.9957 11.2169 11.1814L2.7169 20.1824C2.62728 20.28 2.51916 20.3587 2.39884 20.4142C2.27851 20.4696 2.14837 20.5005 2.01598 20.5052C1.88358 20.51 1.75157 20.4883 1.62761 20.4416C1.50366 20.3948 1.39022 20.3239 1.2939 20.2329C1.19758 20.142 1.1203 20.0328 1.06653 19.9117C1.01276 19.7907 0.98359 19.6601 0.980706 19.5277C0.977821 19.3952 1.00128 19.2635 1.04973 19.1402C1.09817 19.0169 1.17063 18.9045 1.2629 18.8094L9.1149 10.4944L1.2629 2.18139Z"
    ></path>
  </svg> -->

  <button
    class="model-hyper"
    @mouseover="isHovered = true"
    @mouseleave="isHovered = false"
  >
    <div class="CTAarrowBtn">
      <svg
        width="12"
        height="21"
        viewBox="0 0 10 16"
        :style="{ fill: isHovered ? 'black' : 'white' }"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M7.51753 8L0.511964 1.02242C0.454286 0.966194 0.408687 0.899435 0.377806 0.826012C0.346924 0.752589 0.331373 0.673959 0.332053 0.594673C0.332732 0.515386 0.349628 0.437018 0.381765 0.364102C0.413901 0.291186 0.460638 0.225172 0.519272 0.169877C0.577906 0.114583 0.647272 0.0711079 0.723357 0.0419673C0.799442 0.0128267 0.880734 -0.00140064 0.962529 0.000108658C1.04432 0.00161796 1.125 0.0188339 1.19988 0.0507603C1.27477 0.0826866 1.34238 0.128689 1.3988 0.186106L8.82344 7.58184C8.93582 7.69379 8.9987 7.84381 8.9987 8C8.9987 8.15619 8.93582 8.30621 8.82344 8.41816L1.3988 15.8139C1.34238 15.8713 1.27477 15.9173 1.19988 15.9492C1.125 15.9812 1.04432 15.9984 0.962529 15.9999C0.880734 16.0014 0.799442 15.9872 0.723357 15.958C0.647272 15.9289 0.577906 15.8854 0.519272 15.8301C0.460638 15.7748 0.413901 15.7088 0.381765 15.6359C0.349628 15.563 0.332732 15.4846 0.332053 15.4053C0.331373 15.326 0.346924 15.2474 0.377806 15.174C0.408687 15.1006 0.454286 15.0338 0.511964 14.9776L7.51753 8Z"
        />
      </svg>
      <div class="title">{{ msg }}</div>
    </div>
  </button>
</template>

<script>
export default {
  data() {
    return {
      isHovered: false,
    };
  },
  props: {
    isHovered: Boolean,
    msg: String,
  },
  methods: {
    toggleHover() {
      this.isHovered = !this.isHovered;
    },
  },
};
</script>

<style scoped>
img {
  width: 16px;
}

.hovered {
  fill: #000; /* Change to your desired hover color */
}

.CTAarrowBtn {
  display: flex;
  align-items: center;
  gap: 12px;

  font-family: Poppins;
  font-size: 18px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
}

button.model-hyper:hover {
  /* background-color: #e0ff36;
  color: transparent;
  background-clip: text;
  -webkit-background-clip: text; */

  background-color: #e0ff36;
  color: black;

  border: 1px solid transparent;
  transition: ease-in 0s all;
}

/* button.model-hyper:hover .title {
  text styling
} */

button.model-hyper {
  display: flex;
  padding: 12px 36px;
  justify-content: center;
  align-items: center;
  gap: 12px;
  border: 1px solid var(--White, #fff);
  font-family: Poppins;
  font-size: 18px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
  background-color: #e0ff36;
  background: transparent;
}
</style>
