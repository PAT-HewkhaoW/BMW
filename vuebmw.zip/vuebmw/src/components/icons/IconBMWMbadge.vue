<template lang="">
  <img src="../../assets/Mbadge.png" alt="" srcset="" />
</template>

<style>
img {
  width: 98px;
  height: auto;
}
</style>
