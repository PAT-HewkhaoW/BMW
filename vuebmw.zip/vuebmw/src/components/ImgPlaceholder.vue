<script>
import IconBMWMbadge from "./icons/IconBMWMbadge.vue";
import SpecContainer from "../components/SpecContainer.vue";
export default {
  components: { IconBMWMbadge, SpecContainer },
};
</script>

<template>
  <div class="placeholder">
    <div class="title">
      <div class="model-title">
        <div class="main-model font-avenir-heavy">THE M4</div>
        <div class="sub-model">
          THE ALL-NEW BMW 4 SERIES COUPÉ M AUTOMOBILES
        </div>
      </div>
      <div class="model-badge">
        <div class="badge"><IconBMWMbadge /></div>
        <div class="badge-subtitle txt-subtitle-1">
          BMW M4 Compitetion coupé shown
        </div>
      </div>
    </div>
    <div class="background-img"></div>
    <div class="content"><SpecContainer /></div>
  </div>
</template>
<style lang="css" scoped>
.placeholder {
  width: 100%;
  height: 100vh;
  overflow: hidden;

  background-image: url("https://cdn.bmwblog.com/wp-content/uploads/2022/11/BMW-M4-Competition-with-Alcantara-9-scaled.jpg");
  /* https://hips.hearstapps.com/hmg-prod/images/cobb-3movie-180221-1153-1615301729.jpg?:resize=2000* */
  background-size: 140vw;
  background-repeat: no-repeat;
  background-position: 80% 40%;
}

.content {
  position: absolute;
  bottom: 0%;
  left: 50%;
  transform: translate(-50%, 0%);
  text-align: center;
  color: #fff;
}

.main-model,
.sub-model {
  text-align: left;
}

.badge-subtitle {
  text-align: end;
  overflow: hidden;
  white-space: nowrap;
}

.title {
  width: 100%;
  position: absolute;
  display: flex;
  top: 6%;
  left: 0%;
  padding: 6%;
  color: #fff;
  text-align: center;
  justify-content: space-between;
  align-items: flex-start;
}

.model-title {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.model-title .main-model {
  /* font-family: Montserrat; */
  font-size: 94px;
  font-style: normal;
  font-weight: 400;
  line-height: 90px;
}

.model-title .sub-model {
  font-family: Arial;
  font-size: 24px;
  font-style: normal;
  font-weight: 200;
  line-height: 32px;
  letter-spacing: 0.5 px;
}

.title .model-badge {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 10px;
}

.title .model-badge .sub-title {
  font-family: Arial;
  font-size: 17px;
  font-style: normal;
  font-weight: 400;
  line-height: 32px;
}
</style>
