<script>
import IconBMWDark from "./icons/iconBMWDark.vue";
import IconBMWLight from "./icons/IconBMWLight.vue";
export default {
  components: { IconBMWLight, IconBMWDark },
  methods: {
    dropdownToggle() {
      this.isDropdown = !this.isDropdown;
    },
  },
  props: {},

  data() {
    return {
      isDropdown: false,
    };
  },
};
</script>

<template>
  <div id="NavMain">
    <div class="NavContainer" :class="{ bblack: isDropdown }">
      <div id="LNav" class="flexNav">
        <!-- this is left Nav -->

        <div class="branding">
          <IconBMWLight v-show="!isDropdown" />
          <IconBMWDark v-show="isDropdown" />
        </div>
        <div class="Navitem">
          <ul>
            <li class="item" :class="{ tblack: isDropdown }">Models</li>
            <li class="item" :class="{ tblack: isDropdown }">Configurtor</li>
            <li class="item" :class="{ tblack: isDropdown }">Shop Online</li>
            <li class="item" :class="{ tblack: isDropdown }">More BMW</li>
          </ul>
        </div>
      </div>
      <div class="RNav flexNav">
        <!-- this is right Nav -->

        <div class="hamburgerNav" @click="dropdownToggle">
          <span :class="{ bgblack: isDropdown }"></span>
          <span :class="{ bgblack: isDropdown }"></span>
          <span :class="{ bgblack: isDropdown }"></span>
        </div>
      </div>
    </div>
    <div class="dropdown-nav" v-show="isDropdown">
      <div class="login">
        <p>ยินดีต้อนรับเข้าสู่ My BMW</p>
        <div class="ads">
          <p>ลงทะเบียนและรับสิทธิประโยชน์จาก:</p>
          <ul>
            <li>รับสิทธิประโยชน์จากบริการดิจิทัลของ BMW ConnectedDrive</li>
            <li>บันทึกรถยนต์ในฝันของท่าน</li>
            <li>จองการทดลองขับรถยนต์ในฝันของท่าน</li>
          </ul>
          <a href="../.././Yok/signup.html" id="login">Log In</a>
        </div>
      </div>
    </div>
  </div>
</template>
<style scoped>
.tblack {
  color: black !important;
  transition: 0.4s ease all;
}
.bblack {
  border-color: black !important;
  transition: 0.4s ease all;
}
.bgblack {
  background-color: black !important;
  transition: 0.4s ease all;
}
.lgblack {
  fill: black !important;
  transition: 0.4s ease all;
}
#NavMain {
  display: flex;

  width: calc(100vw);
  position: absolute;
  top: 0;
  left: 0;
}
.flexNav {
  display: flex;
}

.branding,
.Navitem > .item,
.RNav {
  padding: 1rem 0rem;
}

.NavContainer {
  margin: 0 6vw;
  padding: 1px 0;
  z-index: 10;
  border-bottom: 1px solid var(--vt-c-text-dark-1);
}

/* item start */
.Navitem > ul {
  padding: 0 16px;
  height: 100%;
  display: inline-table;
  align-items: center;
}

.Navitem > ul > li.item {
  display: table-cell;
  vertical-align: middle;
  position: relative;
  text-decoration: none;
  transition: border-bottom 0.1s ease-in-out;
  padding: 0 20px;
  font-weight: 700;
  color: var(--vt-c-text-dark-1);
}

.Navitem > ul > li.item:hover {
  border-bottom: 7px solid;
  border-color: var(--vt-c-primary);
}
.Navitem > ul > li.item::after {
  content: "";
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  transform: scaleX(0);
  transform-origin: top;
  transition: transform 0.1s ease-in-out;
}

.Navitem > ul > li.item:hover::after {
  transform: scaleX(1);
  transform-origin: left;
}
/* item end */

.NavContainer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  gap: 1.5rem;
}

/* RNav */

.RNav {
  height: 100%;
  display: flex;
  align-items: center;
}
/* Hamburger btn */

.hamburgerNav {
  padding: 2px 16px;
  height: 24px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: auto;

  cursor: pointer;
}

.hamburgerNav span {
  display: block;
  width: 30px;
  height: 2px;
  background-color: var(--vt-c-text-dark-1);
  border-radius: 20px;
}

/* hamburger end */
/* dropdown */

.dropdown-nav {
  width: 100vw;
  position: absolute;
  z-index: 1;
  background-color: white;
  padding-top: 150px;
  transition: 0.4s ease all;

  padding-left: 6vw;
  padding-bottom: 4vh;
  color: var(--vt-c-black);
  font-family: Poppins;
}

.ads {
  padding: 0 0 2rem 2rem;
}
.ads ul li {
  list-style: disc !important;
}

.ads > ul {
  margin-bottom: 20px;
}

.ads a.login {
  color: var(--vt-c-black);
  border: 2px solid black;
  padding: 10px 24px;
}
.ads p {
  font-size: 19px !important;
  font-weight: 500;
}

.login > p {
  font-size: 24px;
  padding-bottom: 20px;
}
</style>
